start util64.exe lfs.txt
